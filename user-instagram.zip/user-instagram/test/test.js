require("../index").getUserData("edouard_courty")
  .then(console.log)
  .catch(console.error);

require("../index").getPostData("CHN1U3TF3VH")
  .then(console.log)
  .catch(console.error);
