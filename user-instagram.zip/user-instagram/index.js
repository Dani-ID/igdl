const {getUserData, getPostData} = require('./src/scrape');

module.exports = getUserData;
module.exports.getUserData = getUserData;
module.exports.getPostData = getPostData;
